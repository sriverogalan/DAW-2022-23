package org.catalegpelicules.texte;

public class Texte {
    public static void menuBaseDeDades() {
        System.out.println("Elige una opcion:");
        System.out.println("1. MySQL");
        System.out.println("2. PostgreSQL");
    }

    public static void menuOpcions() {
        System.out.println("Elige una opcion:");
        System.out.println("1. Llistar peliculas");
        System.out.println("2. Llistar generes");
        System.out.println("3. Crear genere");
        System.out.println("4. Crear pelicula");
        System.out.println("5. Cercar pelicula");
        System.out.println("6. Sobre escriure pelicula");
        System.out.println("7. Sobre escriure genero");
        System.out.println("8. Borrar pelicula");
        System.out.println("9. Borrar genero");
        System.out.println("10. Reiniciar cataleg");
        System.out.println("11. Sortir");
    }

    public static void separtacio() {
        System.out.println();
        System.out.println("--------------------------------------------------");
        System.out.println();
    }
}