package org.catalegpelicules.presentacio;


public class Main {
    public static void main(String[] args) {
        new Projecte1().menuPrincipal();
    }
}