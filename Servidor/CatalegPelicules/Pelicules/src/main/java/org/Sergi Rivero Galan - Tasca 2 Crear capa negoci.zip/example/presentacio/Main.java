package org.example.presentacio;


public class Main {
    public static void main(String[] args) {
         new Projecte1().menuPrincipal();
    }
}